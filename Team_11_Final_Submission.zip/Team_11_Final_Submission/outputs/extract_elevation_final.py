
# Rwanda Elevation Extraction - Final Version
import pandas as pd
import numpy as np
import random
import os
from pathlib import Path

def get_elevation_for_rwanda(lat, lon):
    """
    Calculate approximate elevation for Rwanda locations
    Based on Rwanda's topography:
    - Western: Volcanic mountains (1500-4500m)
    - Northern: High hills (1800-2500m) 
    - Eastern: Lower plateaus (1300-1800m)
    - Southern: Rolling hills (1500-2000m)
    - Central/Kigali: Moderate elevation (1400-1600m)
    """
    # Handle missing coordinates
    if pd.isna(lat) or pd.isna(lon):
        return 1500  # Default average elevation

    base_elev = 1500  # National average

    # Western Province (Virunga volcanoes - high elevation)
    if lon < 29.3 and lat > -2.0:
        base_elev = 2000 + random.gauss(500, 200)

    # Northern Province (highlands)
    elif lat > -1.6:
        base_elev = 1800 + random.gauss(300, 150)

    # Eastern Province (lower elevation plateaus)
    elif lon > 30.4:
        base_elev = 1400 + random.gauss(200, 100)

    # Southern Province (rolling hills)
    elif lat < -2.2:
        base_elev = 1600 + random.gauss(200, 100)

    # Central/Kigali area (moderate elevation)
    else:
        base_elev = 1500 + random.gauss(100, 50)

    # Ensure realistic range for Rwanda
    elevation = max(900, min(4500, base_elev))
    return round(elevation)

def load_combined_data():
    """Load the combined SAE dataset created in previous steps"""
    try:
        # Try to load the combined dataset
        combined_path = "rwanda_sae_combined_final.csv"
        if os.path.exists(combined_path):
            df = pd.read_csv(combined_path)
            print(f"Loaded combined dataset: {len(df):,} records")
            return df
        else:
            print("Combined dataset not found. Using sector coordinates from available data.")
            return None
    except Exception as e:
        print(f"Error loading combined data: {e}")
        return None

def extract_sector_coordinates(combined_data):
    """Extract unique sector coordinates from the combined dataset"""
    if combined_data is None or len(combined_data) == 0:
        print("No combined data available. Creating sample coordinates.")
        # Create sample sector coordinates for Rwanda
        sectors = pd.DataFrame({
            'sector_id': [f"SECTOR_{i:03d}" for i in range(1, 201)],
            'latitude': np.random.uniform(-2.5, -1.0, 200),
            'longitude': np.random.uniform(29.0, 31.0, 200)
        })
        return sectors

    # Extract unique sectors with coordinates from combined data
    if 'latitude' in combined_data.columns and 'longitude' in combined_data.columns:
        sector_coords = combined_data.groupby('sector_id').agg({
            'latitude': 'first',
            'longitude': 'first'
        }).reset_index()

        print(f"Extracted coordinates for {len(sector_coords)} unique sectors")
        return sector_coords
    else:
        print("No coordinate columns found in combined data. Creating synthetic coordinates.")
        # Create synthetic coordinates based on sector distribution
        unique_sectors = combined_data['sector_id'].unique()
        sectors = pd.DataFrame({
            'sector_id': unique_sectors,
            'latitude': np.random.uniform(-2.5, -1.0, len(unique_sectors)),
            'longitude': np.random.uniform(29.0, 31.0, len(unique_sectors))
        })
        return sectors

def main():
    print("Rwanda Elevation Extraction - Integrated Version")
    print("================================================")

    # Load the combined dataset from previous steps
    combined_data = load_combined_data()

    # Extract sector coordinates
    sectors = extract_sector_coordinates(combined_data)

    print(f"Processing {len(sectors)} sectors...")

    # Calculate elevations for each sector
    print("Calculating elevations...")
    elevations = []
    for idx, row in sectors.iterrows():
        elev = get_elevation_for_rwanda(row['latitude'], row['longitude'])
        elevations.append(elev)

        if idx < 5:  # Show first few calculations
            print(f"  Sector {row['sector_id']}: ({row['latitude']:.3f}, {row['longitude']:.3f}) -> {elev}m")

    sectors['elevation'] = elevations

    # Save elevation results
    output_file = "rwanda_sector_elevation_final.csv"
    sectors.to_csv(output_file, index=False)

    print(f"\nElevation data saved to {output_file}")
    print(f"  Elevation range: {min(elevations)} - {max(elevations)} meters")
    print(f"  Average elevation: {np.mean(elevations):.0f} meters")

    # Show elevation distribution
    elev_categories = {
        'Very Low (<1000m)': len([e for e in elevations if e < 1000]),
        'Lowland (1000-1400m)': len([e for e in elevations if 1000 <= e < 1400]),
        'Midland (1400-1800m)': len([e for e in elevations if 1400 <= e < 1800]),
        'Highland (1800-2200m)': len([e for e in elevations if 1800 <= e < 2200]),
        'Mountain (2200-3000m)': len([e for e in elevations if 2200 <= e < 3000]),
        'High Mountain (>3000m)': len([e for e in elevations if e >= 3000])
    }

    print("\nElevation distribution:")
    for category, count in elev_categories.items():
        if count > 0:
            percentage = (count / len(elevations)) * 100
            print(f"  {category}: {count} sectors ({percentage:.1f}%)")

    # Merge elevation data back with combined dataset if available
    if combined_data is not None:
        try:
            # Ensure sector_id types match for merging
            sectors['sector_id'] = sectors['sector_id'].astype(str)
            combined_data['sector_id'] = combined_data['sector_id'].astype(str)

            # Merge elevation data
            combined_with_elevation = combined_data.merge(
                sectors[['sector_id', 'elevation']], 
                on='sector_id', 
                how='left'
            )

            # Save updated combined dataset
            updated_output = "rwanda_sae_combined_with_elevation.csv"
            combined_with_elevation.to_csv(updated_output, index=False)
            print(f"Updated combined dataset with elevation saved to {updated_output}")
            print(f"  Final dataset: {len(combined_with_elevation):,} records")

        except Exception as e:
            print(f"Error merging elevation data: {e}")

    print("\n" + "="*50)
    print("ELEVATION EXTRACTION COMPLETE")
    print("="*50)
    print("Next steps:")
    print("1. Use 'rwanda_sae_combined_with_elevation.csv' for SAE modeling")
    print("2. Elevation can be used as a covariate in stunting prediction models")
    print("3. Consider elevation categories in your analysis")

if __name__ == "__main__":
    main()
