import streamlit as st
import pandas as pd
import geopandas as gpd
import plotly.express as px
import plotly.graph_objects as go
import os

# Page Config
st.set_page_config(page_title="Rwanda SAE Dashboard", layout="wide", page_icon="🗺️")

# Paths
BASE_DIR = r"C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA\Team_11_Final_Submission"
DATA_PATH = os.path.join(BASE_DIR, "Outputs", "rwanda_sae_integrated_final.csv")
SHP_PATH = os.path.join(BASE_DIR, "Boundaries", "shp", "Sector_Boundary_2012", "Sector_Boundary_2012.shp")

# Title
st.title("🇷🇼 Rwanda SAE Project Dashboard")
st.markdown("### Interactive Analysis: Elevation & Stunting Relationship")
st.markdown("---")

# Load Data
@st.cache_data
def load_data():
    if not os.path.exists(DATA_PATH):
        st.error(f"⚠️ Data file not found: {DATA_PATH}")
        st.info("Please run the Rwanda_SAE_Integrated_Analysis.ipynb notebook first to generate the data.")
        return None
    df = pd.read_csv(DATA_PATH)
    return df

@st.cache_data
def load_shapefile():
    if not os.path.exists(SHP_PATH):
        st.warning(f"Shapefile not found: {SHP_PATH}")
        return None
    gdf = gpd.read_file(SHP_PATH)
    return gdf

df = load_data()

if df is not None:
    
    # Sidebar Filters
    st.sidebar.header("📊 Data Filters")
    
    # Filter by Elevation Category
    elev_cats = {1: 'Lowland (<1500m)', 2: 'Midland (1500-1800m)', 3: 'Highland (1800-2200m)', 4: 'Mountain (>2200m)'}
    selected_cats = st.sidebar.multiselect(
        "Select Elevation Categories", 
        options=list(elev_cats.keys()), 
        format_func=lambda x: elev_cats[x], 
        default=[1, 2, 3, 4]
    )
    
    if not selected_cats:
        st.warning("Please select at least one elevation category")
        st.stop()
    
    filtered_df = df[df['elevation_cat'].isin(selected_cats)]
    
    # Key Metrics
    st.subheader("📈 Key Metrics")
    col1, col2, col3, col4 = st.columns(4)
    
    avg_stunting = filtered_df['stunting_rate'].mean()
    total_sectors = len(filtered_df)
    priority_count = len(filtered_df[filtered_df['stunting_rate'] > df['stunting_rate'].quantile(0.90)])
    correlation = filtered_df['stunting_rate'].corr(filtered_df['elevation'])
    
    col1.metric("📍 Total Sectors", total_sectors)
    col2.metric("🎯 Avg Stunting Rate", f"{avg_stunting:.1%}")
    col3.metric("⚠️ Priority Sectors", priority_count)
    col4.metric("📉 Correlation", f"{correlation:.3f}")
    
    st.markdown("---")
    
    # Tabs
    tab1, tab2, tab3 = st.tabs(["📊 Analysis Charts", "🗺️ Geographic Map", "📋 Data Explorer"])
    
    with tab1:
        col_chart1, col_chart2 = st.columns(2)
        
        with col_chart1:
            st.subheader("Elevation vs Stunting Rate")
            
            # Scatter plot without trendline
            fig_scatter = px.scatter(
                filtered_df, 
                x='elevation', 
                y='stunting_rate',
                color='elevation_cat',
                hover_data=['Code_Sect', 'child_count'],
                labels={
                    'elevation': 'Elevation (meters)',
                    'stunting_rate': 'Stunting Rate',
                    'elevation_cat': 'Category'
                },
                color_continuous_scale='Viridis'
            )
            
            fig_scatter.update_layout(
                height=400,
                showlegend=True
            )
            
            st.plotly_chart(fig_scatter, use_container_width=True)
            
            # Correlation info
            st.info(f"**Correlation Coefficient:** {correlation:.4f}")
            
        with col_chart2:
            st.subheader("Distribution by Elevation Category")
            
            # Box plot
            fig_box = px.box(
                filtered_df, 
                x='elevation_cat', 
                y='stunting_rate', 
                color='elevation_cat',
                labels={
                    'elevation_cat': 'Elevation Category',
                    'stunting_rate': 'Stunting Rate'
                }
            )
            
            # Update x-axis labels
            fig_box.update_xaxes(
                ticktext=['Lowland', 'Midland', 'Highland', 'Mountain'],
                tickvals=[1, 2, 3, 4]
            )
            
            fig_box.update_layout(height=400, showlegend=False)
            st.plotly_chart(fig_box, use_container_width=True)
        
        # Summary Statistics
        st.subheader("📊 Summary Statistics by Elevation Category")
        
        summary_stats = filtered_df.groupby('elevation_cat').agg({
            'stunting_rate': ['mean', 'std', 'min', 'max', 'count'],
            'elevation': 'mean'
        }).round(3)
        
        summary_stats.columns = ['_'.join(col).strip() for col in summary_stats.columns.values]
        summary_stats.index = [elev_cats.get(i, f'Category {i}') for i in summary_stats.index]
        
        st.dataframe(summary_stats, use_container_width=True)

    with tab2:
        st.subheader("🗺️ Stunting Prevalence Map")
        
        gdf = load_shapefile()
        
        if gdf is not None:
            # Find matching column
            match_col = None
            for col in gdf.columns:
                if 'sect' in col.lower() and 'id' in col.lower():
                    match_col = col
                    break
            if not match_col and 'IF_ID' in gdf.columns:
                match_col = 'IF_ID'
            
            if match_col:
                gdf['Code_Sect'] = pd.to_numeric(gdf[match_col], errors='coerce').fillna(0).astype(int)
                map_data = gdf.merge(filtered_df, on='Code_Sect', how='inner')
                
                if len(map_data) > 0:
                    # Interactive Choropleth Map
                    fig_map = px.choropleth_mapbox(
                        map_data,
                        geojson=map_data.geometry,
                        locations=map_data.index,
                        color="stunting_rate",
                        hover_data=["Code_Sect", "elevation", "stunting_rate", "child_count"],
                        color_continuous_scale="RdYlGn_r",
                        mapbox_style="carto-positron",
                        center={"lat": -2.0, "lon": 30.0},
                        zoom=6.5,
                        opacity=0.7,
                        labels={'stunting_rate': 'Stunting Rate'}
                    )
                    
                    fig_map.update_layout(
                        margin={"r":0,"t":0,"l":0,"b":0},
                        height=600
                    )
                    
                    st.plotly_chart(fig_map, use_container_width=True)
                else:
                    st.warning("No geographic data could be matched with the selected filters.")
            else:
                st.error("Could not identify sector ID column in shapefile.")
        else:
            st.warning("Map visualization unavailable (shapefile not found)")

    with tab3:
        st.subheader("📋 Detailed Sector Data")
        
        # Priority threshold
        threshold = df['stunting_rate'].quantile(0.90)
        
        # Add priority flag
        display_df = filtered_df.copy()
        display_df['Priority'] = display_df['stunting_rate'] > threshold
        
        # Select columns to display
        display_cols = ['Code_Sect', 'elevation', 'elevation_cat', 'stunting_rate', 
                       'child_count', 'Priority']
        
        # Format the dataframe
        styled_df = display_df[display_cols].copy()
        styled_df['elevation_cat'] = styled_df['elevation_cat'].map(elev_cats)
        styled_df['stunting_rate'] = styled_df['stunting_rate'].apply(lambda x: f"{x:.2%}")
        
        # Sort by stunting rate (highest first)
        styled_df = styled_df.sort_values('stunting_rate', ascending=False)
        
        st.dataframe(
            styled_df,
            use_container_width=True,
            height=400
        )
        
        # Download button
        csv = filtered_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Download Filtered Data (CSV)",
            data=csv,
            file_name="rwanda_sae_filtered_data.csv",
            mime="text/csv"
        )
        
        # Priority sectors summary
        st.info(f"**Priority Intervention Zones:** {priority_count} sectors with stunting rate > {threshold:.2%}")

else:
    st.error("❌ Unable to load data. Please ensure the analysis notebook has been run successfully.")
    st.info("""
    **Steps to generate data:**
    1. Open `Rwanda_SAE_Integrated_Analysis.ipynb`
    2. Run all cells in the notebook
    3. This will create `rwanda_sae_integrated_final.csv`
    4. Refresh this dashboard
    """)
