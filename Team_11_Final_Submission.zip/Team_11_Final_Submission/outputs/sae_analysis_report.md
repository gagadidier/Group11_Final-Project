# Rwanda SAE Analysis: Elevation & Stunting Relationship

## Executive Summary

**Analysis Date**: 2025-11-20 09:09  
**Total Sectors Analyzed**: 50  
**Total Children**: 3,006  

### Key Findings

1. **Stunting Prevalence**: 25.7% average across sectors
2. **Elevation Range**: 1187 - 2194 meters
3. **Correlation**: Elevation-stunting correlation: 0.327
4. **Priority Areas**: 
   - 2 sectors require mountain-adapted interventions
   - 0 sectors need standard nutrition programs

### Data Sources
- DHS 2019-20 Children's Recode
- Rwanda Population and Housing Census
- Elevation data extracted from coordinates
