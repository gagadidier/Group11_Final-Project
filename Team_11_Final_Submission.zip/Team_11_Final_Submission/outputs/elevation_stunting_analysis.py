
# Rwanda Elevation-Stunting Analysis
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

def analyze_elevation_stunting():
    """Analyze relationship between elevation and stunting"""
    print("Rwanda Elevation-Stunting Analysis")
    print("=" * 50)

    try:
        # Load enhanced dataset
        df = pd.read_csv("rwanda_sae_combined_with_elevation.csv")
        print(f"Loaded dataset: {len(df):,} records")

        # Check required variables
        if 'elevation' not in df.columns or 'stunting_rate' not in df.columns:
            print("Missing required variables (elevation or stunting_rate)")
            return

        # Create sector-level analysis
        sector_data = df.groupby('sector_id').agg({
            'stunting_rate': 'mean',
            'elevation': 'mean',
            'elevation_category': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Unknown'
        }).reset_index()

        sector_data = sector_data.dropna(subset=['stunting_rate', 'elevation'])
        print(f"Sectors with complete data: {len(sector_data)}")

        if len(sector_data) < 10:
            print("Insufficient data for analysis")
            return

        # Basic statistics
        print(f"\nBasic Statistics:")
        print(f"Stunting rate - Mean: {sector_data['stunting_rate'].mean():.3f}")
        print(f"Stunting rate - Std: {sector_data['stunting_rate'].std():.3f}")
        print(f"Elevation - Mean: {sector_data['elevation'].mean():.0f}m")
        print(f"Elevation - Std: {sector_data['elevation'].std():.0f}m")

        # Correlation analysis
        correlation = sector_data['stunting_rate'].corr(sector_data['elevation'])
        print(f"\nCorrelation between elevation and stunting: {correlation:.3f}")

        # Analysis by elevation category
        print(f"\nStunting by Elevation Category:")
        elev_analysis = sector_data.groupby('elevation_category').agg({
            'stunting_rate': ['mean', 'std', 'count'],
            'elevation': 'mean'
        }).round(3)
        print(elev_analysis)

        # Simple visualization (if matplotlib is available)
        try:
            plt.figure(figsize=(10, 6))

            # Scatter plot
            plt.subplot(1, 2, 1)
            plt.scatter(sector_data['elevation'], sector_data['stunting_rate'], alpha=0.6)
            plt.xlabel('Elevation (m)')
            plt.ylabel('Stunting Rate')
            plt.title('Elevation vs Stunting Rate')

            # Box plot by elevation category
            plt.subplot(1, 2, 2)
            sector_data.boxplot(column='stunting_rate', by='elevation_category', ax=plt.gca())
            plt.xticks(rotation=45)
            plt.suptitle('Stunting Rate by Elevation Category')
            plt.tight_layout()
            plt.savefig('elevation_stunting_analysis.png', dpi=300, bbox_inches='tight')
            print("\nSaved visualization: elevation_stunting_analysis.png")

        except Exception as e:
            print(f"Could not create visualization: {e}")

        # Priority analysis
        print(f"\nPriority Zones Analysis:")
        sector_data['priority_zone'] = np.select([
            (sector_data['stunting_rate'] > 0.35) & (sector_data['elevation'] > 1600),
            (sector_data['stunting_rate'] > 0.35) & (sector_data['elevation'] <= 1600),
            (sector_data['stunting_rate'] <= 0.35)
        ], [
            'High Priority: High stunting + High elevation',
            'Medium Priority: High stunting + Lower elevation',
            'Lower Priority: Lower stunting'
        ])

        priority_counts = sector_data['priority_zone'].value_counts()
        for zone, count in priority_counts.items():
            percentage = (count / len(sector_data)) * 100
            print(f"  {zone}: {count} sectors ({percentage:.1f}%)")

        # Save analysis results
        sector_data.to_csv('elevation_stunting_analysis_results.csv', index=False)
        print("\nAnalysis results saved to: elevation_stunting_analysis_results.csv")

    except Exception as e:
        print(f"Error in analysis: {e}")

if __name__ == "__main__":
    analyze_elevation_stunting()
