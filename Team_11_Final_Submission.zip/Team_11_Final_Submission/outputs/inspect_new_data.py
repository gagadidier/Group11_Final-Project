import pandas as pd
import numpy as np
import os

# Paths
stunting_path = r"C:\Users\NISR\Desktop\USA World_Bank\My new Project\rwanda_dhs_stunting_final.csv"
sector_path = r"c:/Users/NISR/Desktop/gaga/AIMS/my project SAE/SEA RWANDA/Team_11_Final_Submission/outputs/sae_sector_final.csv"

def inspect_data():
    print(f"Loading Stunting Data: {stunting_path}")
    try:
        # Try reading with low memory to just get structure first if large, but file is ~8MB so it's fine.
        df_stunting = pd.read_csv(stunting_path)
        print(f"[OK] Stunting Data Loaded. Shape: {df_stunting.shape}")
        print("Columns:", df_stunting.columns.tolist())
        
        # Check for key columns
        key_cols = ['Code_Prov', 'Code_Dist', 'Code_Sect', 'v040', 'stunting_cat', 'haz']
        for col in key_cols:
            if col in df_stunting.columns:
                print(f"Found column: {col}")
                print(f"Sample values: {df_stunting[col].head(5).tolist()}")
                print(f"Nulls: {df_stunting[col].isnull().sum()}")
            else:
                print(f"[-] MISSING column: {col}")

        # Check v040 (Elevation) validity
        if 'v040' in df_stunting.columns:
            valid_elev = df_stunting['v040'].notna() & (df_stunting['v040'] != 9999) # 9999 is often missing in DHS
            print(f"Valid Elevation entires: {valid_elev.sum()} / {len(df_stunting)}")
            print(f"Elevation statistics:\n{df_stunting.loc[valid_elev, 'v040'].describe()}")

    except Exception as e:
        print(f"Error loading stunting data: {e}")
        return

    print("\n" + "="*30 + "\n")

    print(f"Loading Sector Data: {sector_path}")
    try:
        df_sector = pd.read_csv(sector_path)
        print(f"[OK] Sector Data Loaded. Shape: {df_sector.shape}")
        print("Columns:", df_sector.columns.tolist())
        
        if 'sector_id' in df_sector.columns:
            print(f"Sector ID Sample: {df_sector['sector_id'].head().tolist()}")
            print(f"Sector ID Type: {df_sector['sector_id'].dtype}")
    except Exception as e:
        print(f"Error loading sector data: {e}")
        return

    # Attempt to verify link
    print("\n" + "="*30 + "\n")
    print("Checking ID Linkage...")
    
    # Construct ID in stunting if possible
    # Assuming Sector ID in census is likely Prov(1)+Dist(2)+Sect(2) -> 5 digits? or just a sequential ID?
    # Let's see the sector_id sample from above first.
    
    # If df_stunting has codes, let's try to construct a similar ID
    # Usually: Prov * 10000 + Dist * 100 + Sect
    # Or just numeric concatenation
    
    if all(col in df_stunting.columns for col in ['Code_Prov', 'Code_Dist', 'Code_Sect']):
        try:
            # Clean and convert to numeric
            p = pd.to_numeric(df_stunting['Code_Prov'], errors='coerce').fillna(0).astype(int)
            d = pd.to_numeric(df_stunting['Code_Dist'], errors='coerce').fillna(0).astype(int)
            s = pd.to_numeric(df_stunting['Code_Sect'], errors='coerce').fillna(0).astype(int)
            
            # Construct candidate IDs
            df_stunting['candidate_id_1'] = p * 10000 + d * 100 + s
            df_stunting['candidate_id_2'] = d * 100 + s # Sometimes just Dist+Sect
            
            print(f"Constructed Candidate ID 1 Sample: {df_stunting['candidate_id_1'].head().tolist()}")
            
            # Check overlap
            sector_ids = set(df_sector['sector_id'].unique())
            
            overlap1 = df_stunting['candidate_id_1'].isin(sector_ids).sum()
            print(f"Overlap with Candidate ID 1 (Prov+Dist+Sect): {overlap1} rows matched out of {len(df_stunting)}")
            
            overlap2 = df_stunting['candidate_id_2'].isin(sector_ids).sum()
            print(f"Overlap with Candidate ID 2 (Dist+Sect): {overlap2} rows matched out of {len(df_stunting)}")
            
        except Exception as e:
            print(f"Error constructing IDs: {e}")

if __name__ == "__main__":
    inspect_data()
