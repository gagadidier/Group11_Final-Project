import pandas as pd
import pyreadstat

census_path = r"C:\Users\NISR\Desktop\USA World_Bank\Census_data.sav"

def list_all_columns():
    print(f"--- Listing Columns in {census_path} ---")
    try:
        df, meta = pyreadstat.read_sav(census_path, metadataonly=True)
        columns = meta.column_names
        labels = meta.column_names_to_labels
        
        print(f"Total Columns: {len(columns)}")
        print("="*40)
        for col in columns:
            label = labels.get(col, "")
            print(f"{col}: {label}")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    list_all_columns()
