import pandas as pd
import pyreadstat

# File Paths
census_path = r"C:\Users\NISR\Desktop\USA World_Bank\Census_data.sav"
dhs_kr_path = r"C:\Users\NISR\Desktop\USA World_Bank\My new Project\RWKR81FL (2).DTA"
dhs_ir_path = r"C:\Users\NISR\Desktop\USA World_Bank\My new Project\RWIR81FL (2).DTA"
dhs_hr_path = r"C:\Users\NISR\Desktop\USA World_Bank\My new Project\RWHR81FL (2).DTA"

def inspect_file(path, file_type="sav"):
    print(f"\n--- Inspecting {path} ---")
    try:
        if file_type == "sav":
            # read_spss might be slow for huge files, reading metadata only if possible would be better
            # but pandas read_spss doesn't support nrows. 
            # Using pyreadstat directly is better for metadata.
            df, meta = pyreadstat.read_sav(path, metadataonly=True)
            columns = meta.column_names
            print(f"[OK] Metadata read successfully.")
            print(f"Number of variables: {len(columns)}")
            print(f"Number of rows: {meta.number_of_observations}")
        else:
            # For Stata files
            df = pd.read_stata(path, iterator=True)
            meta = df.variable_labels()
            columns = list(meta.keys())
            print(f"[OK] Stata file opened successfully.")
            print(f"Number of variables: {len(columns)}")
            
        
        # Search for key variables
        search_terms = ['sect', 'code', 'elev', 'alt', 'lat', 'lon', 'coord', 'stunt', 'haz', 'hw70']
        found_vars = []
        for col in columns:
            col_lower = col.lower()
            if any(term in col_lower for term in search_terms):
                found_vars.append(col)
                
        print("\nPossible Key Variables Found:")
        print(found_vars)
        
        if 'Code_Sect' in columns:
            print("\n[+] CONFIRMED: 'Code_Sect' exists in this file.")
        else:
            print("\n[-] WARNING: 'Code_Sect' NOT found explicitly (check case/spelling in list above).")

    except Exception as e:
        print(f"Error reading file: {e}")

if __name__ == "__main__":
    inspect_file(census_path, "sav")
    inspect_file(dhs_kr_path, "dta")
    # inspect_file(dhs_ir_path, "dta") # Optional, focusing on kids first
