
# Rwanda Elevation-Stunting Relationship Visualization
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import os

# Set style
plt.style.use('default')
sns.set_palette("husl")

def create_visualizations():
    print("Creating Elevation-Stunting Visualizations...")

    try:
        # Try to load analysis data
        data = pd.read_csv("elevation_stunting_analysis.csv")
        data_source = "Analysis Data"
        print(f"[OK] Loaded analysis data: {len(data)} sectors")
    except FileNotFoundError:
        try:
            # Fall back to sector data
            data = pd.read_csv("sae_sector_final.csv")
            data_source = "Sector Data"
            print(f"[OK] Loaded sector data: {len(data)} sectors")
        except FileNotFoundError:
            print("[-] No data files found. Please run the analysis first.")
            print("Available files in current directory:")
            for file in os.listdir('.'):
                if file.endswith('.csv'):
                    print(f"  - {file}")
            return

    print(f"Using {data_source}")
    print(f"Number of sectors: {len(data)}")

    # Check required columns
    required_cols = ['elevation', 'stunting_rate']
    missing_cols = [col for col in required_cols if col not in data.columns]
    if missing_cols:
        print(f"[-] Missing required columns: {missing_cols}")
        print(f"Available columns: {list(data.columns)}")
        return

    # Create enhanced data for visualization
    viz_data = data.copy()

    # Create elevation categories if not present
    if 'elevation_category' not in viz_data.columns:
        conditions = [
            viz_data['elevation'] < 1200,
            (viz_data['elevation'] >= 1200) & (viz_data['elevation'] < 1500),
            (viz_data['elevation'] >= 1500) & (viz_data['elevation'] < 1800),
            (viz_data['elevation'] >= 1800) & (viz_data['elevation'] < 2200),
            viz_data['elevation'] >= 2200
        ]
        categories = [
            'Very Low (<1200m)', 
            'Lowland (1200-1500m)', 
            'Midland (1500-1800m)', 
            'Highland (1800-2200m)', 
            'Mountain (>2200m)'
        ]
        viz_data['elevation_category'] = np.select(conditions, categories, default='Unknown')

    # Create priority zones if not present
    if 'priority_zone' not in viz_data.columns:
        viz_data['priority_zone'] = np.select([
            (viz_data['stunting_rate'] > 0.35) & (viz_data['elevation'] > 1600),
            (viz_data['stunting_rate'] > 0.35) & (viz_data['elevation'] <= 1600),
            (viz_data['stunting_rate'] <= 0.35) & (viz_data['stunting_rate'] > 0.25),
            (viz_data['stunting_rate'] <= 0.25)
        ], [
            'High Priority: High stunting + High elevation',
            'Medium Priority: High stunting + Lower elevation', 
            'Watch List: Moderate stunting',
            'Lower Priority: Lower stunting'
        ], default='Unknown')

    # Create figure with subplots
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle(f'Rwanda: Elevation-Stunting Relationship Analysis\n{data_source} - {len(viz_data)} Sectors', 
                fontsize=16, fontweight='bold', y=0.98)

    # Plot 1: Scatter plot with regression line and density
    ax1 = axes[0, 0]

    # Create scatter plot with color by density
    # Filter for valid data
    valid_plot_data = viz_data.dropna(subset=['elevation', 'stunting_rate'])
    
    if len(valid_plot_data) > 1:
        scatter = ax1.scatter(valid_plot_data['elevation'], valid_plot_data['stunting_rate'], 
                             c=valid_plot_data['stunting_rate'], cmap='viridis', alpha=0.7, 
                             s=50, edgecolors='white', linewidth=0.5)

        # Add regression line
        try:
            z = np.polyfit(valid_plot_data['elevation'], valid_plot_data['stunting_rate'], 1)
            p = np.poly1d(z)
            x_range = np.linspace(valid_plot_data['elevation'].min(), valid_plot_data['elevation'].max(), 100)
            ax1.plot(x_range, p(x_range), "r--", alpha=0.8, linewidth=2, label='Regression line')
        except Exception as e:
            print(f"[-] Could not fit regression line: {e}")
        # Add correlation
        correlation = valid_plot_data['stunting_rate'].corr(valid_plot_data['elevation'])
        ax1.set_title(f'Elevation vs Stunting Rate\nCorrelation: r = {correlation:.3f}', fontsize=12)
        ax1.legend()
        
        # Add colorbar
        cbar = plt.colorbar(scatter, ax=ax1)
        cbar.set_label('Stunting Rate', rotation=270, labelpad=15)

    else:
        ax1.text(0.5, 0.5, "Insufficient data for scatter plot\n(Need both elevation and stunting data)", 
                ha='center', va='center', transform=ax1.transAxes)
        ax1.set_title('Elevation vs Stunting Rate (No Data)', fontsize=12)

    ax1.set_xlabel('Elevation (meters)', fontsize=10)
    ax1.set_ylabel('Stunting Rate', fontsize=10)
    ax1.grid(True, alpha=0.3)

    # Plot 2: Box plot by elevation category
    ax2 = axes[0, 1]

    # Order categories by elevation
    elevation_order = ['Very Low (<1200m)', 'Lowland (1200-1500m)', 'Midland (1500-1800m)', 
                      'Highland (1800-2200m)', 'Mountain (>2200m)']
    available_categories = [cat for cat in elevation_order if cat in viz_data['elevation_category'].values]

    if available_categories:
        sns.boxplot(data=viz_data, x='elevation_category', y='stunting_rate', 
                   order=available_categories, ax=ax2)
        ax2.set_title('Stunting Rates by Elevation Category', fontsize=12)
        ax2.set_xlabel('Elevation Category', fontsize=10)
        ax2.set_ylabel('Stunting Rate', fontsize=10)
        plt.setp(ax2.get_xticklabels(), rotation=45, ha='right', fontsize=9)

        # Add mean values on the plot
        for i, category in enumerate(available_categories):
            cat_data = viz_data[viz_data['elevation_category'] == category]['stunting_rate']
            mean_val = cat_data.mean()
            ax2.text(i, mean_val + 0.02, f'{mean_val:.3f}', 
                    ha='center', va='bottom', fontweight='bold', fontsize=8)

    # Plot 3: Distribution of stunting rates with statistics
    ax3 = axes[1, 0]

    sns.histplot(data=viz_data, x='stunting_rate', kde=True, ax=ax3, bins=20)

    # Add statistical lines
    mean_stunting = viz_data['stunting_rate'].mean()
    median_stunting = viz_data['stunting_rate'].median()

    ax3.axvline(mean_stunting, color='red', linestyle='--', linewidth=2,
               label=f'Mean: {mean_stunting:.3f}')
    ax3.axvline(median_stunting, color='blue', linestyle='--', linewidth=2,
               label=f'Median: {median_stunting:.3f}')

    ax3.set_title('Distribution of Stunting Rates Across Sectors', fontsize=12)
    ax3.set_xlabel('Stunting Rate', fontsize=10)
    ax3.set_ylabel('Number of Sectors', fontsize=10)
    ax3.legend()
    ax3.grid(True, alpha=0.3)

    # Plot 4: Priority zones pie chart
    ax4 = axes[1, 1]

    priority_counts = viz_data['priority_zone'].value_counts()

    # Define colors for priority zones
    priority_colors = {
        'High Priority: High stunting + High elevation': '#e74c3c',  # Red
        'Medium Priority: High stunting + Lower elevation': '#f39c12',  # Orange
        'Watch List: Moderate stunting': '#f1c40f',  # Yellow
        'Lower Priority: Lower stunting': '#27ae60'   # Green
    }

    # Get colors in correct order
    colors = [priority_colors.get(zone, '#95a5a6') for zone in priority_counts.index]

    wedges, texts, autotexts = ax4.pie(priority_counts.values, 
                                      labels=priority_counts.index,
                                      autopct='%1.1f%%', 
                                      colors=colors,
                                      startangle=90,
                                      textprops={'fontsize': 9})

    # Improve text appearance
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
        autotext.set_fontsize(8)

    ax4.set_title('Priority Zones for Intervention', fontsize=12)

    plt.tight_layout()
    plt.savefig('elevation_stunting_visualization.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.show()

    # Print comprehensive summary
    print("\n" + "="*60)
    print("COMPREHENSIVE ANALYSIS SUMMARY")
    print("="*60)

    print(f"\n[-] BASIC STATISTICS:")
    print(f"   Number of sectors analyzed: {len(viz_data):,}")
    print(f"   Average stunting rate: {viz_data['stunting_rate'].mean():.3f} ({viz_data['stunting_rate'].mean()*100:.1f}%)")
    print(f"   Stunting rate range: {viz_data['stunting_rate'].min():.3f} - {viz_data['stunting_rate'].max():.3f}")
    print(f"   Average elevation: {viz_data['elevation'].mean():.0f} meters")
    print(f"   Elevation range: {viz_data['elevation'].min():.0f} - {viz_data['elevation'].max():.0f} meters")

    print(f"\n[-] CORRELATION ANALYSIS:")
    print(f"   Correlation coefficient: {correlation:.3f}")

    # Interpret correlation
    if abs(correlation) < 0.1:
        strength = "very weak"
    elif abs(correlation) < 0.3:
        strength = "weak"
    elif abs(correlation) < 0.5:
        strength = "moderate"
    elif abs(correlation) < 0.7:
        strength = "strong"
    else:
        strength = "very strong"

    direction = "positive" if correlation > 0 else "negative"
    print(f"   Interpretation: {strength} {direction} relationship")

    print(f"\n[-] PRIORITY ZONE BREAKDOWN:")
    for zone, count in priority_counts.items():
        percentage = (count / len(viz_data)) * 100
        print(f"   {zone}: {count} sectors ({percentage:.1f}%)")

    print(f"\n[-] ELEVATION CATEGORY ANALYSIS:")
    for category in available_categories:
        cat_data = viz_data[viz_data['elevation_category'] == category]
        avg_stunting = cat_data['stunting_rate'].mean()
        avg_elev = cat_data['elevation'].mean()
        count = len(cat_data)
        print(f"   {category}: {avg_stunting:.3f} stunting rate, {count} sectors, {avg_elev:.0f}m avg elevation")

    print(f"\n[-] KEY INSIGHTS:")
    high_priority_count = len(viz_data[viz_data['priority_zone'].str.contains('High Priority')])
    if high_priority_count > 0:
        print(f"   • {high_priority_count} sectors identified as high priority for intervention")

    if correlation > 0.2:
        print("   • Higher elevation areas tend to have higher stunting rates")
    elif correlation < -0.2:
        print("   • Lower elevation areas tend to have higher stunting rates")
    else:
        print("   • No strong linear relationship between elevation and stunting")

    print(f"\n[OK] Visualizations created and saved as:")
    print(f"   - elevation_stunting_visualization.png (high-quality image)")
    print(f"   - Analysis summary printed above")

if __name__ == "__main__":
    create_visualizations()
