# Rwanda SAE Dashboard - Launch Instructions

## Quick Start

### Option 1: Using Python Module (Recommended)
```bash
cd "C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA\Team_11_Final_Submission\Outputs"
python -m streamlit run dashboard_app.py
```

### Option 2: Direct Command (if streamlit is in PATH)
```bash
cd "C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA\Team_11_Final_Submission\Outputs"
streamlit run dashboard_app.py
```

## What the Dashboard Shows

### 📊 Analysis Charts Tab
- **Scatter Plot**: Elevation vs Stunting Rate relationship
- **Box Plot**: Distribution by elevation categories
- **Summary Statistics**: Detailed stats for each elevation category

### 🗺️ Geographic Map Tab
- Interactive choropleth map showing stunting prevalence across Rwanda
- Hover over sectors to see details
- Color-coded by stunting rate

### 📋 Data Explorer Tab
- Sortable table of all sectors
- Priority sectors highlighted
- Download filtered data as CSV

## Features

✅ **Interactive Filters**: Select elevation categories in the sidebar
✅ **Key Metrics**: Average stunting rate, total sectors, priority zones, correlation
✅ **High-Quality Visualizations**: Interactive Plotly charts
✅ **Data Export**: Download filtered data for further analysis
✅ **Priority Identification**: Automatically identifies top 10% sectors needing intervention

## Troubleshooting

If the dashboard doesn't load:
1. Make sure you ran the Jupyter notebook first to generate `rwanda_sae_integrated_final.csv`
2. Check that all packages are installed: `pip install streamlit plotly geopandas pandas`
3. Restart your terminal and try again

The dashboard will open automatically in your browser at `http://localhost:8501`
