import pandas as pd
import pyreadstat

census_path = r"C:\Users\NISR\Desktop\USA World_Bank\Census_data.sav"

def inspect_census_columns():
    print(f"--- Inspecting {census_path} ---")
    try:
        # metadataonly=True is faster
        df, meta = pyreadstat.read_sav(census_path, metadataonly=True)
        columns = meta.column_names
        print(f"[OK] Metadata read. {len(columns)} variables found.")
        
        # Search for interesting variables
        keywords = ['code', 'sect', 'elev', 'alt', 'lat', 'lon', 'gps', 'coord', 'height']
        found = []
        for col in columns:
            if any(k in col.lower() for k in keywords):
                found.append(col)
                # print labels if available
                if col in meta.column_names_to_labels:
                    print(f"  {col}: {meta.column_names_to_labels[col]}")
                else:
                    print(f"  {col}")
        
        # specific verify
        if 'Code_Sect' in columns:
            print("\n[+] Found 'Code_Sect' in Census.")
        else:
            print("\n[-] 'Code_Sect' NOT found in Census (check list above).")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    inspect_census_columns()
