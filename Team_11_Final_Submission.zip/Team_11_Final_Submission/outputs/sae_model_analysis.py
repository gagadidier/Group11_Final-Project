
# Rwanda Small Area Estimation - Model Analysis
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

print("Rwanda SAE Model Analysis")
print("=" * 50)

def load_sae_data():
    """Load SAE datasets"""
    try:
        # Load sector-level data
        sector_data = pd.read_csv("sae_sector_final.csv")
        print(f"Loaded sector data: {len(sector_data)} sectors")

        # Load household-level data
        household_data = pd.read_csv("sae_household_final.csv")
        print(f"Loaded household data: {len(household_data)} households")

        return sector_data, household_data

    except FileNotFoundError as e:
        print(f"Error loading data: {e}")
        return None, None

def basic_descriptive_analysis(sector_data):
    """Perform basic descriptive analysis"""
    print("\n--- BASIC DESCRIPTIVE ANALYSIS ---")

    if sector_data is None:
        print("No sector data available")
        return

    # Stunting analysis
    if 'stunting_rate' in sector_data.columns:
        valid_stunting = sector_data[sector_data['stunting_rate'].notna()]
        print(f"Sectors with stunting data: {len(valid_stunting)}")

        if len(valid_stunting) > 0:
            print(f"Stunting rate statistics:")
            print(f"  Mean: {valid_stunting['stunting_rate'].mean():.3f}")
            print(f"  Std:  {valid_stunting['stunting_rate'].std():.3f}")
            print(f"  Min:  {valid_stunting['stunting_rate'].min():.3f}")
            print(f"  Max:  {valid_stunting['stunting_rate'].max():.3f}")

    # Elevation analysis
    if 'elevation' in sector_data.columns:
        valid_elevation = sector_data[sector_data['elevation'].notna()]
        print(f"\nElevation statistics:")
        print(f"  Mean: {valid_elevation['elevation'].mean():.0f}m")
        print(f"  Std:  {valid_elevation['elevation'].std():.0f}m")

def elevation_stunting_analysis(sector_data):
    """Analyze relationship between elevation and stunting"""
    print("\n--- ELEVATION-STUNTING ANALYSIS ---")

    if sector_data is None or 'elevation' not in sector_data.columns or 'stunting_rate' not in sector_data.columns:
        print("Missing required data for elevation-stunting analysis")
        return

    valid_data = sector_data[['elevation', 'stunting_rate']].dropna()
    if len(valid_data) < 10:
        print("Insufficient data for analysis")
        return

    # Correlation
    correlation = valid_data['stunting_rate'].corr(valid_data['elevation'])
    print(f"Correlation between elevation and stunting: {correlation:.3f}")

    # Simple scatter plot
    try:
        plt.figure(figsize=(10, 6))
        plt.scatter(valid_data['elevation'], valid_data['stunting_rate'], alpha=0.6)
        plt.xlabel('Elevation (m)')
        plt.ylabel('Stunting Rate')
        plt.title('Elevation vs Stunting Rate in Rwanda Sectors')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig('elevation_stunting_scatter.png', dpi=300, bbox_inches='tight')
        print("Saved scatter plot: elevation_stunting_scatter.png")
    except Exception as e:
        print(f"Could not create plot: {e}")

def priority_zone_analysis(sector_data):
    """Identify priority zones for intervention"""
    print("\n--- PRIORITY ZONE ANALYSIS ---")

    if sector_data is None or 'stunting_rate' not in sector_data.columns:
        print("Missing stunting data for priority analysis")
        return

    valid_data = sector_data[sector_data['stunting_rate'].notna()].copy()

    # Define priority zones
    conditions = [
        (valid_data['stunting_rate'] > 0.35),
        (valid_data['stunting_rate'] > 0.25) & (valid_data['stunting_rate'] <= 0.35),
        (valid_data['stunting_rate'] <= 0.25)
    ]
    choices = ['High Priority', 'Medium Priority', 'Lower Priority']

    valid_data['priority_zone'] = np.select(conditions, choices, default='Unknown')

    priority_counts = valid_data['priority_zone'].value_counts()
    print("Priority zones distribution:")
    for zone, count in priority_counts.items():
        percentage = (count / len(valid_data)) * 100
        print(f"  {zone}: {count} sectors ({percentage:.1f}%)")

def main():
    """Main analysis function"""
    print("Starting SAE Model Analysis...")

    # Load data
    sector_data, household_data = load_sae_data()

    # Perform analyses
    basic_descriptive_analysis(sector_data)
    elevation_stunting_analysis(sector_data)
    priority_zone_analysis(sector_data)

    print("\n" + "="*50)
    print("SAE ANALYSIS COMPLETE")
    print("="*50)
    print("Next steps:")
    print("1. Review the generated plots and statistics")
    print("2. Use these results to inform SAE model selection")
    print("3. Consider spatial autocorrelation in your models")
    print("4. Validate models with domain knowledge")

if __name__ == "__main__":
    main()
