import pandas as pd
import numpy as np
import os
import pyreadstat
import matplotlib.pyplot as plt
import seaborn as sns

# DATA PATHS (As provided by User)
PATHS = {
    'dhs_kr': r"C:\Users\NISR\Desktop\USA World_Bank\My new Project\RWKR81FL (2).DTA",  # Children (Stunting)
    'census': r"C:\Users\NISR\Desktop\USA World_Bank\Census_data.sav"                 # Census Data
}

def process_dhs_children():
    print("\n--- Processing DHS Children (KR) Data ---")
    fpath = PATHS['dhs_kr']
    if not os.path.exists(fpath):
        print(f"[-] File not found: {fpath}")
        return None
    
    try:
        df = pd.read_stata(fpath, convert_categoricals=False)
        print(f"[OK] Loaded DHS: {len(df)} records.")
        
        # Verify Code_Sect
        if 'Code_Sect' not in df.columns:
            print("[-] 'Code_Sect' NOT found in DHS.")
            return None
            
        # Calculate Stunting
        if 'hw70' in df.columns:
            mask_valid = df['hw70'] < 9990 
            df.loc[mask_valid, 'is_stunted'] = (df.loc[mask_valid, 'hw70'] < -200).astype(int)
            valid_count = mask_valid.sum()
            print(f"[OK] Valid stunting Data: {valid_count}")
        else:
            print("[-] 'hw70' missing.")
            return None

        # Aggregate
        sector_agg = df[mask_valid].groupby('Code_Sect').agg(
            stunting_rate=('is_stunted', 'mean'),
            child_count=('is_stunted', 'count')
        ).reset_index()
        
        print(f"[OK] DHS Aggregated: {len(sector_agg)} Sectors.")
        return sector_agg

    except Exception as e:
        print(f"[-] Error processing DHS: {e}")
        return None

def process_census_data():
    print("\n--- Processing Census Data ---")
    fpath = PATHS['census']
    if not os.path.exists(fpath):
        print(f"[-] File not found: {fpath}")
        return None

    try:
        # Load Census (using pyreadstat) with specific columns to save memory
        target_cols = ['ml01', 'ml02', 'ml03', 'altitude', 'latitude', 'longitude']
        print(f"Loading Census data (cols={target_cols})...")
        
        # Checking if use_cols is supported (it is in recent pyreadstat versions)
        # Note: column names in SAV might be case sensitive or uppercase. 
        # Ideally we read metadata first to get correct casing.
        
        _, meta = pyreadstat.read_sav(fpath, metadataonly=True)
        all_cols = meta.column_names
        
        # Case-insensitive match for target columns
        actual_cols = []
        for target in target_cols:
            for col in all_cols:
                if target.lower() == col.lower():
                    actual_cols.append(col)
                    break
        
        if len(actual_cols) < len(target_cols):
            print(f"[-] Warning: Not all columns found. Found: {actual_cols}")
        
        df, meta = pyreadstat.read_sav(fpath, usecols=actual_cols)
        print(f"[OK] Loaded Census: {len(df)} records.")
        
        # Normalize columns
        df.columns = [c.lower() for c in df.columns]
        
        # ID Creation (SPSS Logic)
        # District_code = (ml01 * 10) + ml02
        # Sector_code = (District_code * 100) + ml03
        
        print("Creating Identifiers...")
        for c in ['ml01', 'ml02', 'ml03']:
            df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0).astype(int)

        df['District_code'] = (df['ml01'] * 10) + df['ml02']
        df['Code_Sect'] = (df['District_code'] * 100) + df['ml03']
        
        print(f"[+] Created 'Code_Sect' sample: {df['Code_Sect'].head().tolist()}")

        # Aggregate Elevation
        if 'altitude' in df.columns:
            sector_summary = df.groupby('Code_Sect').agg(
                elevation=('altitude', 'mean'),
                census_pop=('ml01', 'count')
            ).reset_index()
            print(f"[OK] Census Aggregated: {len(sector_summary)} Sectors.")
            return sector_summary
        else:
            print("[-] 'altitude' column missing in Census.")
            return None

    except Exception as e:
        print(f"[-] Error processing Census: {e}")
        return None

def main():
    dhs = process_dhs_children()
    census = process_census_data()
    
    if dhs is not None and census is not None:
        # Standardize types
        dhs['Code_Sect'] = dhs['Code_Sect'].astype(int)
        census['Code_Sect'] = census['Code_Sect'].astype(int)
        
        print("\n--- Merging ---")
        merged = pd.merge(dhs, census, on='Code_Sect', how='inner')
        print(f"[OK] Merged Shape: {merged.shape}")
        print(f"[OK] Matched Sectors: {merged['Code_Sect'].nunique()}")
        
        if not merged.empty:
            print("\nSample Data:")
            print(merged.head())
            print(f"\nCorrelation (Elev vs Stunting): {merged['elevation'].corr(merged['stunting_rate']):.4f}")
        else:
            print("[-] Merge resulted in empty dataset. Check IDs.")
            print(f"DHS IDs sample: {dhs['Code_Sect'].head().tolist()}")
            print(f"Census IDs sample: {census['Code_Sect'].head().tolist()}")

if __name__ == "__main__":
    main()
