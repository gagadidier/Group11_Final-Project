import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Create dummy data if real data verification is too slow/complex for this specific plot check
# But better to use the integrated data we just verified we can create.

# Re-using the logic from verify_notebook_logic.py but adding the new analysis steps
# to confirm they work.

def verify_analysis_features():
    print("\n--- Verifying Feature Engineering & Analysis ---")
    
    # Simulate a merged dataframe based on what we know exists
    # If we can load the real one, great. If not, we simulate.
    # We will try to load the one we created in previous verification step if it was saved?
    # Actually, previous verification didn't save to file, it just printed.
    
    # Let's create a synthetic dataframe that mimics the structure for testing the PLOTTING code
    # This is faster than reloading 4GB of census data again.
    
    data = {
        'Code_Sect': range(1, 101),
        'elevation': np.random.uniform(1000, 3000, 100),
        'stunting_rate': np.random.uniform(0.1, 0.5, 100)
    }
    df = pd.DataFrame(data)
    
    # 1. Feature Engineering Logic
    conditions = [
        (df['elevation'] < 1500),
        (df['elevation'] >= 1500) & (df['elevation'] < 1800),
        (df['elevation'] >= 1800) & (df['elevation'] < 2200),
        (df['elevation'] >= 2200)
    ]
    choices = [1, 2, 3, 4]
    df['elevation_cat'] = np.select(conditions, choices, default=1)
    
    # Quantiles
    df['stunting_level'] = pd.qcut(df['stunting_rate'], q=4, labels=False) + 1
    
    print("[OK] Features Created.")
    print(df.head())
    
    # 2. Analysis Function Logic (User's Code adapted)
    try:
        print("\n--- Testing Analysis Function ---")
        
        # Basic stats
        print(f"Stunting Mean: {df['stunting_rate'].mean():.3f}")
        
        # Correlation
        corr = df['stunting_rate'].corr(df['elevation'])
        print(f"Correlation: {corr:.3f}")
        
        # Plotting (Validation: check for no errors)
        plt.figure(figsize=(10, 6))
        scatter = plt.scatter(df['elevation'], df['stunting_rate'], 
                             c=df['stunting_level'], cmap='RdYlGn_r')
        plt.colorbar(scatter)
        plt.close() # Don't show, just ensuring it runs
        print("[OK] Scatter Plot logic works.")
        
        # Boxplot logic
        elevation_cat_names = ['Lowland', 'Midland', 'Highland', 'Mountain']
        box_data = []
        for cat in [1, 2, 3, 4]:
            box_data.append(df[df['elevation_cat'] == cat]['stunting_rate'].values)
            
        plt.figure()
        plt.boxplot(box_data, labels=elevation_cat_names)
        plt.close()
        print("[OK] Box Plot logic works.")
        
        # Summary
        summary = df.groupby('elevation_cat').agg({
            'stunting_rate': ['mean', 'count']
        })
        print(summary)
        
    except Exception as e:
        print(f"[-] Analysis Function Failed: {e}")
        raise e

if __name__ == "__main__":
    verify_analysis_features()
