import pandas as pd
import numpy as np
import os
import pyreadstat
from pathlib import Path

# Paths
BASE_DIR = Path(r"C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA\Team_11_Final_Submission")
OUTPUT_DIR = BASE_DIR / "Outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

PATHS = {
    'dhs_kr': r"C:\Users\NISR\Desktop\USA World_Bank\My new Project\RWKR81FL (2).DTA", 
    'census': r"C:\Users\NISR\Desktop\USA World_Bank\Census_data.sav"
}

def generate_data():
    print("Generating Dashboard Data...")

    # 1. DHS
    print("Loading DHS...")
    dhs = pd.read_stata(PATHS['dhs_kr'], convert_categoricals=False)
    
    # Rename Sector Code if needed
    if 'Code_Sect' not in dhs.columns:
        for a in ['shsect', 'ssect', 'sect']:
            if a in dhs.columns:
                dhs.rename(columns={a: 'Code_Sect'}, inplace=True)
                break
    
    # Calc Stunting
    mask = dhs['hw70'] < 9990
    dhs.loc[mask, 'is_stunted'] = (dhs.loc[mask, 'hw70'] < -200).astype(int)
    
    dhs_agg = dhs[mask].groupby('Code_Sect').agg(
        stunting_rate=('is_stunted', 'mean'),
        child_count=('is_stunted', 'count')
    ).reset_index()
    dhs_agg['Code_Sect'] = dhs_agg['Code_Sect'].astype(int)

    # 2. Census
    print("Loading Census (optimized)...")
    target_cols = ['ml01', 'ml02', 'ml03', 'altitude']
    
    # Case insensitive load
    _, meta = pyreadstat.read_sav(PATHS['census'], metadataonly=True)
    all_cols = meta.column_names
    actual_cols = [c for c in all_cols if c.lower() in [t.lower() for t in target_cols]]
    
    census, _ = pyreadstat.read_sav(PATHS['census'], usecols=actual_cols)
    census.columns = [c.lower() for c in census.columns]
    
    # ID Creation
    census['ml01'] = pd.to_numeric(census['ml01'], errors='coerce').fillna(0).astype(int)
    census['ml02'] = pd.to_numeric(census['ml02'], errors='coerce').fillna(0).astype(int)
    census['ml03'] = pd.to_numeric(census['ml03'], errors='coerce').fillna(0).astype(int)
    
    census['dist_code'] = (census['ml01'] * 10) + census['ml02']
    census['Code_Sect'] = (census['dist_code'] * 100) + census['ml03']
    
    census_agg = census.groupby('Code_Sect').agg(
        elevation=('altitude', 'mean'),
        pop_count=('ml01', 'count')
    ).reset_index()
    census_agg['Code_Sect'] = census_agg['Code_Sect'].astype(int)

    # 3. Merge
    print("Merging...")
    final = pd.merge(dhs_agg, census_agg, on='Code_Sect', how='inner')
    
    # 4. Features
    conditions = [
        (final['elevation'] < 1500),
        (final['elevation'] >= 1500) & (final['elevation'] < 1800),
        (final['elevation'] >= 1800) & (final['elevation'] < 2200),
        (final['elevation'] >= 2200)
    ]
    choices = [1, 2, 3, 4] # keeping as int for dashboard mapping
    final['elevation_cat'] = np.select(conditions, choices, default=1)
    final['stunting_level'] = pd.qcut(final['stunting_rate'], q=4, labels=False) + 1
    
    save_path = OUTPUT_DIR / "rwanda_sae_integrated_final.csv"
    final.to_csv(save_path, index=False)
    print(f"Success! Saved to {save_path}")

if __name__ == "__main__":
    generate_data()
