# Rwanda SAE - Correlation Analysis
import pandas as pd
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# SETUP PATHS
BASE_PATH = Path(r"C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA")
OUTPUT_DIR = BASE_PATH / "Outputs"
FIGURES_DIR = OUTPUT_DIR / "Figures"
FIGURES_DIR.mkdir(parents=True, exist_ok=True)

def analyze_correlation():
    print("Running Correlation Analysis: Stunting vs Elevation")
    print("=================================================")
    
    # 1. Load Data
    data_path = OUTPUT_DIR / "rwanda_sae_combined_with_elevation.csv"
    
    if not data_path.exists():
        print(f"Error: Dataset not found at {data_path}")
        print("Please run 'extract_elevation_final.py' first to generate this file.")
        
        # Fallback to combined dataset if elevation missing
        data_path = OUTPUT_DIR / "sae_combined_dataset.csv"
        if data_path.exists():
            print(f"Found {data_path} (without elevation). Checking contents...")
        else:
            return

    df = pd.read_csv(data_path)
    print(f"Loaded {len(df):,} records")
    
    # 2. Check for required columns
    required_cols = ['Code_Sect', 'stunting_rate', 'elevation']
    missing_cols = [c for c in required_cols if c not in df.columns]
    
    # If missing, try to create synthetic for demonstration if user wants "is it possible"
    if missing_cols:
        print(f"Warning: Missing columns: {missing_cols}")
        
        if 'stunting_rate' in missing_cols and 'elevation' in df.columns:
            print("Stunting rate missing. Cannot calculate correlation.")
        elif 'elevation' in missing_cols:
             print("Elevation missing. Cannot calculate correlation.")
             
        # Check if we assume simulated data for testing
        # (Only if requested, but better to exit if real data expected)
        return

    # 3. Aggregate to Sector Level
    print("Aggregating to sector level...")
    sector_df = df.groupby('Code_Sect').agg({
        'stunting_rate': 'mean',
        'elevation': 'mean'
    }).reset_index()
    
    # Drop NaNs
    sector_df = sector_df.dropna()
    print(f"Analyzed {len(sector_df)} sectors with valid data")
    
    if len(sector_df) < 2:
        print("Not enough data points for correlation.")
        return

    # 4. Calculate Correlation
    corr_r, p_val = stats.pearsonr(sector_df['elevation'], sector_df['stunting_rate'])
    corr_rho, s_p_val = stats.spearmanr(sector_df['elevation'], sector_df['stunting_rate'])
    
    print("\n--- Correlation Results ---")
    print(f"Pearson Correlation (r):   {corr_r:.4f} (p-value: {p_val:.4f})")
    print(f"Spearman Correlation (rho): {corr_rho:.4f} (p-value: {s_p_val:.4f})")
    
    if p_val < 0.05:
        print(">> Significant correlation detected!")
    else:
        print(">> Correlation not statistically significant.")
        
    if corr_r < 0:
        print(">> Negative relationship: Higher elevation -> Lower stunting (generally)")
    else:
        print(">> Positive relationship: Higher elevation -> Higher stunting")

    # 5. Plot
    plt.figure(figsize=(10, 6))
    sns.regplot(x='elevation', y='stunting_rate', data=sector_df, 
                scatter_kws={'alpha':0.6}, line_kws={'color':'red', 'label': f'r={corr_r:.2f}'})
    
    plt.title(f'Correlation: Stunting Rate vs Elevation (n={len(sector_df)})')
    plt.xlabel('Elevation (meters)')
    plt.ylabel('Stunting Rate')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    save_path = FIGURES_DIR / "correlation_stunting_elevation.png"
    plt.savefig(save_path)
    print(f"\nSaved correlation plot to {save_path}")

if __name__ == "__main__":
    analyze_correlation()
