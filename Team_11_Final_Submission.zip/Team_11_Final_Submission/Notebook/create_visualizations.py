# Rwanda SAE Visualization Script
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# SETUP PATHS
BASE_PATH = Path(r"C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA")
OUTPUT_DIR = BASE_PATH / "Outputs"
FIGURES_DIR = OUTPUT_DIR / "Figures"
FIGURES_DIR.mkdir(parents=True, exist_ok=True)

def load_data():
    """Load the final data"""
    data_path = OUTPUT_DIR / "rwanda_sae_combined_with_elevation.csv"
    if not data_path.exists():
        print(f"Data not found: {data_path}")
        return None
    return pd.read_csv(data_path)

def create_visualizations(df):
    print("Generating visualizations...")
    
    # Set style
    sns.set(style="whitegrid")
    
    # 1. Elevation Distribution
    plt.figure(figsize=(10, 6))
    if 'elevation' in df.columns:
        sns.histplot(df['elevation'], bins=30, kde=True, color='skyblue')
        plt.title('Distribution of Sector Elevations in Rwanda')
        plt.xlabel('Elevation (meters)')
        plt.ylabel('Frequency')
        plt.savefig(FIGURES_DIR / "elevation_distribution.png")
        print("Saved elevation_distribution.png")
    
    # 2. Wealth Index Distribution
    # Use categorical wealth if available (wealth_q1...q5 are binary dummies in my prep code)
    # Reconstruct categorical for plotting if needed
    plt.figure(figsize=(10, 6))
    wealth_cols = [f'wealth_q{i}' for i in range(1, 6)]
    if all(c in df.columns for c in wealth_cols):
        # Calculate sums
        wealth_counts = df[wealth_cols].sum()
        wealth_counts.index = ['Poorest', 'Poorer', 'Middle', 'Richer', 'Richest']
        wealth_counts.plot(kind='bar', color='green', alpha=0.7)
        plt.title('Distribution of Wealth Quintiles')
        plt.ylabel('Count')
        plt.savefig(FIGURES_DIR / "wealth_distribution.png")
        print("Saved wealth_distribution.png")
        
    # 3. Elevation Map (Scatter of Lat/Lon)
    if 'latitude' in df.columns and 'longitude' in df.columns and 'elevation' in df.columns:
        plt.figure(figsize=(10, 8))
        scatter = plt.scatter(df['longitude'], df['latitude'], 
                             c=df['elevation'], cmap='terrain', 
                             alpha=0.6, s=20)
        plt.colorbar(scatter, label='Elevation (m)')
        plt.title('Geographic Distribution of Elevation')
        plt.xlabel('Longitude')
        plt.ylabel('Latitude')
        plt.savefig(FIGURES_DIR / "elevation_map.png")
        print("Saved elevation_map.png")
        
    # 4. Stunting vs Elevation (if available)
    if 'stunting_rate' in df.columns:
        # Aggregate to sector level for clearer plot
        sector_df = df.groupby('Code_Sect')[['stunting_rate', 'elevation']].mean().reset_index()
        
        plt.figure(figsize=(10, 6))
        sns.regplot(x='elevation', y='stunting_rate', data=sector_df, 
                   scatter_kws={'alpha':0.5}, line_kws={'color':'red'})
        plt.title('Relationship between Elevation and Stunting Rate')
        plt.xlabel('Elevation (m)')
        plt.ylabel('Stunting Rate')
        plt.savefig(FIGURES_DIR / "stunting_vs_elevation.png")
        print("Saved stunting_vs_elevation.png")

def main():
    df = load_data()
    if df is not None:
        create_visualizations(df)
        print("Visualization Complete. Check 'Outputs/Figures' folder.")

if __name__ == "__main__":
    main()
