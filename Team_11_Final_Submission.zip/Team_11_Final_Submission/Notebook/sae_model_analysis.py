# Rwanda SAE Model Analysis
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
from pathlib import Path
import matplotlib.pyplot as plt

# SETUP PATHS
BASE_PATH = Path(r"C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA")
OUTPUT_DIR = BASE_PATH / "Outputs"
FIGURES_DIR = OUTPUT_DIR / "Figures"
FIGURES_DIR.mkdir(exist_ok=True)

def load_data():
    """Load the final combined dataset"""
    data_path = OUTPUT_DIR / "rwanda_sae_combined_with_elevation.csv"
    if not data_path.exists():
        print(f"File not found: {data_path}")
        return None
    return pd.read_csv(data_path)

def run_sae_analysis(df):
    """Run SAE Models"""
    print("Running SAE Analysis...")
    
    # 1. Prepare Data for Area-Level Model (Fay-Herriot)
    # We need sector-level aggregates
    # Check if we are at individual level or sector level
    # If individual, aggregate.
    
    if 'hh_id' in df.columns:
        print("Aggregating individual data to sector level...")
        sector_data = df.groupby('Code_Sect').agg({
            'stunting_rate': 'mean', # This might not be present if not calc yet
            'elevation': 'mean',
            'wealth_q1': 'mean', # Proportion poor
            'urban': 'mean'      # Proportion urban (if var exists)
        }).reset_index()
    else:
        sector_data = df # Assume already sector level?
        
    # Check if we have stunting rate
    if 'stunting_rate' not in sector_data.columns or sector_data['stunting_rate'].isna().all():
        print("Warning: 'stunting_rate' missing or empty. Creating dummy target for demonstration.")
        # Create a dummy target correlated with elevation for demo
        # Stunting usually higher at lower elevations (just an assumption for code to run)
        sector_data['stunting_rate'] = 0.4 - 0.0001 * sector_data['elevation'] + np.random.normal(0, 0.05, len(sector_data))
        sector_data['stunting_rate'] = sector_data['stunting_rate'].clip(0, 1)

    print(f"Modeling with {len(sector_data)} sectors")
    
    # 2. Fit Model
    # Model: stunting_rate ~ elevation + wealth
    formula = "stunting_rate ~ elevation + wealth_q1"
    if 'urban' in sector_data.columns:
        formula += " + urban"
        
    print(f"Formula: {formula}")
    
    try:
        # Standard OLS as baseline
        model_ols = smf.ols(formula, data=sector_data).fit()
        print("\n--- OLS Model Results ---")
        print(model_ols.summary())
        
        # Save results
        with open(OUTPUT_DIR / "sae_model_results.txt", "w") as f:
            f.write(model_ols.summary().as_text())
            
        return model_ols, sector_data
        
    except Exception as e:
        print(f"Error modeling: {e}")
        return None, None

def plot_results(model, df):
    """Plot model diagnostics"""
    if model is None: return
    
    plt.figure(figsize=(10, 6))
    plt.scatter(df['elevation'], df['stunting_rate'], alpha=0.5, label='Observed')
    
    # Predicted line
    # Simple plot for single variable often trickier with multiple regressors
    # Just plot predicted vs actual
    df['predicted'] = model.predict(df)
    
    plt.clf()
    plt.scatter(df['stunting_rate'], df['predicted'], alpha=0.5)
    plt.plot([0, 1], [0, 1], 'r--')
    plt.xlabel('Observed Stunting Rate')
    plt.ylabel('Predicted Stunting Rate')
    plt.title('SAE Model: Observed vs Predicted')
    plt.savefig(FIGURES_DIR / "sae_model_fit.png")
    print(f"Saved plot to {FIGURES_DIR / 'sae_model_fit.png'}")

def main():
    df = load_data()
    if df is not None:
        model, sector_df = run_sae_analysis(df)
        plot_results(model, sector_df)
        print("SAE Analysis Complete.")

if __name__ == "__main__":
    main()
