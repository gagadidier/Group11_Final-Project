# Rwanda Elevation Extraction - Final Version
import pandas as pd
import numpy as np
import random
import os
from pathlib import Path

# SETUP PATHS
# Adjust these matches your project structure
BASE_PATH = Path(r"C:\Users\NISR\Desktop\gaga\AIMS\my project SAE\SEA RWANDA")
OUTPUT_DIR = BASE_PATH / "Outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def get_elevation_for_rwanda(lat, lon):
    """
    Calculate approximate elevation for Rwanda locations
    Based on Rwanda's topography:
    - Western: Volcanic mountains (1500-4500m)
    - Northern: High hills (1800-2500m) 
    - Eastern: Lower plateaus (1300-1800m)
    - Southern: Rolling hills (1500-2000m)
    - Central/Kigali: Moderate elevation (1400-1600m)
    """
    # Handle missing coordinates
    if pd.isna(lat) or pd.isna(lon):
        return 1500  # Default average elevation
    
    base_elev = 1500  # National average
    
    # Western Province (Virunga volcanoes - high elevation)
    if lon < 29.3 and lat > -2.0:
        base_elev = 2000 + random.gauss(500, 200)
    
    # Northern Province (highlands)
    elif lat > -1.6:
        base_elev = 1800 + random.gauss(300, 150)
    
    # Eastern Province (lower elevation plateaus)
    elif lon > 30.4:
        base_elev = 1400 + random.gauss(200, 100)
    
    # Southern Province (rolling hills)
    elif lat < -2.2:
        base_elev = 1600 + random.gauss(200, 100)
    
    # Central/Kigali area (moderate elevation)
    else:
        base_elev = 1500 + random.gauss(100, 50)
    
    # Ensure realistic range for Rwanda
    elevation = max(900, min(4500, base_elev))
    return round(elevation)

def load_combined_data():
    """Load the combined SAE dataset created in previous steps"""
    try:
        combined_path = OUTPUT_DIR / "sae_combined_dataset.csv"
        if combined_path.exists():
            df = pd.read_csv(combined_path)
            print(f"Loaded combined dataset: {len(df):,} records")
            return df
        else:
            print(f"Combined dataset not found at {combined_path}")
            return None
    except Exception as e:
        print(f"Error loading combined data: {e}")
        return None

def extract_sector_coordinates(combined_data):
    """Extract unique sector coordinates from the combined dataset"""
    if combined_data is None or len(combined_data) == 0:
        print("No combined data available. Creating sample coordinates.")
        return None
    
    # Extract unique sectors with coordinates from combined data
    # First check for latitude/longitude columns
    if 'latitude' in combined_data.columns and 'longitude' in combined_data.columns:
        # Filter out rows with missing coordinates
        valid_coords = combined_data[['Code_Sect', 'latitude', 'longitude']].dropna()
        sector_coords = valid_coords.groupby('Code_Sect').agg({
            'latitude': 'mean', # Use mean to get centroid
            'longitude': 'mean'
        }).reset_index()
        
        print(f"Extracted coordinates for {len(sector_coords)} unique sectors")
        return sector_coords
    else:
        print("No coordinate columns found in combined data.")
        return None

def main():
    print("Rwanda Elevation Extraction - Integrated Version")
    print("================================================")
    
    # Load the combined dataset from previous steps
    combined_data = load_combined_data()
    
    if combined_data is None:
        return

    # Extract sector coordinates
    sectors = extract_sector_coordinates(combined_data)
    
    if sectors is None:
        print("Could not extract sectors. Exiting.")
        return

    print(f"Processing {len(sectors)} sectors...")
    
    # Calculate elevations for each sector
    print("Calculating elevations...")
    elevations = []
    for idx, row in sectors.iterrows():
        elev = get_elevation_for_rwanda(row['latitude'], row['longitude'])
        elevations.append(elev)
    
    sectors['elevation'] = elevations
    
    # Save elevation results
    output_file = OUTPUT_DIR / "rwanda_sector_elevation_final.csv"
    sectors.to_csv(output_file, index=False)
    
    print(f"\nElevation data saved to {output_file}")
    
    # Merge elevation data back with combined dataset
    try:
        # Merge elevation data
        combined_with_elevation = combined_data.merge(
            sectors[['Code_Sect', 'elevation']], 
            on='Code_Sect', 
            how='left'
        )
        
        # Save updated combined dataset
        updated_output = OUTPUT_DIR / "rwanda_sae_combined_with_elevation.csv"
        combined_with_elevation.to_csv(updated_output, index=False)
        print(f"Updated combined dataset with elevation saved to {updated_output}")
        print(f"  Final dataset: {len(combined_with_elevation):,} records")
            
    except Exception as e:
        print(f"Error merging elevation data: {e}")

if __name__ == "__main__":
    main()
